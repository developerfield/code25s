# StudyTimer - Android Ders Çalışma Sayacı

## Proje Yapısı
```
app/src/main/
├── java/com/studytimer/app/
│   ├── MainActivity.kt              # Ana ekran
│   ├── service/
│   │   ├── TimerService.kt          # Arka plan timer servisi
│   │   └── FloatingWidgetService.kt # Yüzen bubble servisi
│   ├── ui/
│   │   ├── theme/Theme.kt           # Karanlık/Aydınlık tema
│   │   └── StatsActivity.kt         # İstatistik ekranı
│   ├── tile/
│   │   └── StudyTimerTile.kt        # Quick Settings Tile
│   ├── receiver/
│   │   └── NotificationReceiver.kt  # Bildirim buton alıcısı
│   ├── data/
│   │   ├── SessionDatabase.kt       # Room DB
│   │   └── SessionRepository.kt
│   └── model/
│       └── StudySession.kt          # Veri modeli
├── res/
│   ├── layout/
│   │   ├── activity_main.xml
│   │   ├── floating_widget.xml
│   │   └── activity_stats.xml
│   ├── values/
│   │   ├── colors.xml
│   │   ├── strings.xml
│   │   └── themes.xml
│   └── xml/
│       └── tile_service.xml
└── AndroidManifest.xml
```
