package com.studytimer.app.data

import android.content.Context
import com.studytimer.app.model.StudySession

class SessionRepository(context: Context) {
    private val dao = SessionDatabase.get(context).sessionDao()

    suspend fun insertSession(session: StudySession) = dao.insert(session)
    suspend fun getAllSessions()    = dao.getAll()
    suspend fun totalStudySec()    = dao.totalStudySec() ?: 0L
    suspend fun totalBreakSec()    = dao.totalBreakSec() ?: 0L
    suspend fun weeklyStudySec()   = dao.weeklyStudySec()
}
