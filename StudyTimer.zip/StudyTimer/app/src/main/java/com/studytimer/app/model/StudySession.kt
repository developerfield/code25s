package com.studytimer.app.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Tek bir çalışma/mola oturumunu temsil eden veri modeli.
 */
@Entity(tableName = "sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startTime:   Long,    // Unix timestamp (ms)
    val endTime:     Long,    // Unix timestamp (ms)
    val durationSec: Long,    // Saniye cinsinden süre
    val isStudy:     Boolean  // true=ders, false=mola
)
