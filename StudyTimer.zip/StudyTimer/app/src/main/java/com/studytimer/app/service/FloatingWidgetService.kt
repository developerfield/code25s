package com.studytimer.app.service

import android.app.*
import android.content.*
import android.graphics.PixelFormat
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.studytimer.app.MainActivity
import com.studytimer.app.R

class FloatingWidgetService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatView: View
    private lateinit var tvTime: TextView
    private lateinit var tvMode: TextView
    private lateinit var btnStudy: Button
    private lateinit var btnBreak: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button

    private var isExpanded = false
    private var initialX = 0; private var initialY = 0
    private var initialTouchX = 0f; private var initialTouchY = 0f

    // ── Timer güncellemelerini dinle ─────────────────────────────
    private val timerReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == TimerService.ACTION_TICK) {
                val elapsed   = intent.getLongExtra(TimerService.EXTRA_ELAPSED, 0)
                val running   = intent.getBooleanExtra(TimerService.EXTRA_RUNNING, false)
                val studyMode = intent.getBooleanExtra(TimerService.EXTRA_STUDY_MODE, true)
                updateFloatUI(elapsed, running, studyMode)
            }
        }
    }

    // ────────────────────────────────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(FLOAT_NOTIF_ID, buildNotification())
        inflateWidget()
        registerReceiver()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        if (::floatView.isInitialized) {
            try { windowManager.removeView(floatView) } catch (_: Exception) {}
        }
        LocalBroadcastManager.getInstance(this).unregisterReceiver(timerReceiver)
        super.onDestroy()
    }

    // ── Widget Şişirme ───────────────────────────────────────────
    private fun inflateWidget() {
        floatView = LayoutInflater.from(this).inflate(R.layout.floating_widget, null)

        tvTime  = floatView.findViewById(R.id.floatTimer)
        tvMode  = floatView.findViewById(R.id.floatMode)
        btnStudy= floatView.findViewById(R.id.floatBtnStudy)
        btnBreak= floatView.findViewById(R.id.floatBtnBreak)
        btnStart= floatView.findViewById(R.id.floatBtnStart)
        btnStop = floatView.findViewById(R.id.floatBtnStop)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50; y = 200
        }

        windowManager.addView(floatView, params)
        setupWidgetListeners(params)
    }

    // ── Widget Listener'ları ─────────────────────────────────────
    private fun setupWidgetListeners(params: WindowManager.LayoutParams) {

        // Sürükleme + genişletme/daraltma
        val header = floatView.findViewById<View>(R.id.floatHeader)
        val body   = floatView.findViewById<View>(R.id.floatBody)

        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x; initialY = params.y
                    initialTouchX = event.rawX; initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    // Çok az hareket = tıklama → genişlet/daralt
                    val dx = Math.abs(event.rawX - initialTouchX)
                    val dy = Math.abs(event.rawY - initialTouchY)
                    if (dx < 10 && dy < 10) {
                        isExpanded = !isExpanded
                        body.visibility = if (isExpanded) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }

        // Ders butonu
        btnStudy.setOnClickListener {
            sendCmd(TimerService.CMD_SET_STUDY)
        }

        // Mola butonu
        btnBreak.setOnClickListener {
            sendCmd(TimerService.CMD_SET_BREAK)
        }

        // Başla butonu
        btnStart.setOnClickListener {
            sendCmd(TimerService.CMD_START)
        }

        // Bitir butonu
        btnStop.setOnClickListener {
            sendCmd(TimerService.CMD_STOP)
        }

        // Ana uygulamayı aç (çift tık simülasyonu — header long click)
        header.setOnLongClickListener {
            startActivity(Intent(this, MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            true
        }
    }

    // ── UI Güncelleme ────────────────────────────────────────────
    private fun updateFloatUI(elapsed: Long, running: Boolean, studyMode: Boolean) {
        val h = elapsed / 3600
        val m = (elapsed % 3600) / 60
        val s = elapsed % 60
        tvTime.text = String.format("%02d:%02d:%02d", h, m, s)
        tvMode.text = if (studyMode) "📚" else "☕"
        btnStart.isEnabled = !running
        btnStop.isEnabled  = running
    }

    // ── Yardımcılar ──────────────────────────────────────────────
    private fun sendCmd(action: String) {
        startService(Intent(this, TimerService::class.java).setAction(action))
    }

    private fun registerReceiver() {
        LocalBroadcastManager.getInstance(this).registerReceiver(
            timerReceiver, IntentFilter(TimerService.ACTION_TICK)
        )
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                FLOAT_CHANNEL, "Yüzen Widget", NotificationManager.IMPORTANCE_MIN
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val pi = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, FLOAT_CHANNEL)
            .setSmallIcon(R.drawable.ic_study)
            .setContentTitle("Yüzen Widget Aktif")
            .setContentText("Uygulamayı açmak için dokun")
            .setContentIntent(pi)
            .setSilent(true)
            .build()
    }

    companion object {
        private const val FLOAT_CHANNEL = "float_channel"
        private const val FLOAT_NOTIF_ID = 102
    }
}
