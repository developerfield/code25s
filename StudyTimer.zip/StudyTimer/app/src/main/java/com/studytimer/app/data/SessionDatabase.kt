package com.studytimer.app.data

import android.content.Context
import androidx.room.*
import com.studytimer.app.model.StudySession

// ── DAO ─────────────────────────────────────────────────────────
@Dao
interface SessionDao {
    @Insert
    suspend fun insert(session: StudySession)

    @Query("SELECT * FROM sessions ORDER BY startTime DESC")
    suspend fun getAll(): List<StudySession>

    @Query("SELECT * FROM sessions WHERE isStudy = 1 ORDER BY startTime DESC")
    suspend fun getStudySessions(): List<StudySession>

    @Query("SELECT * FROM sessions WHERE isStudy = 0 ORDER BY startTime DESC")
    suspend fun getBreakSessions(): List<StudySession>

    @Query("SELECT SUM(durationSec) FROM sessions WHERE isStudy = 1")
    suspend fun totalStudySec(): Long?

    @Query("SELECT SUM(durationSec) FROM sessions WHERE isStudy = 0")
    suspend fun totalBreakSec(): Long?

    // Son 7 günün günlük toplamı
    @Query("""
        SELECT strftime('%Y-%m-%d', datetime(startTime/1000, 'unixepoch')) as day,
               SUM(durationSec) as total
        FROM sessions
        WHERE isStudy = 1
          AND startTime > (strftime('%s','now') - 7*86400) * 1000
        GROUP BY day
        ORDER BY day DESC
    """)
    suspend fun weeklyStudySec(): List<DayTotal>
}

data class DayTotal(val day: String, val total: Long)

// ── Database ─────────────────────────────────────────────────────
@Database(entities = [StudySession::class], version = 1, exportSchema = false)
abstract class SessionDatabase : RoomDatabase() {
    abstract fun sessionDao(): SessionDao

    companion object {
        @Volatile private var INSTANCE: SessionDatabase? = null

        fun get(context: Context): SessionDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    SessionDatabase::class.java,
                    "study_sessions.db"
                ).build().also { INSTANCE = it }
            }
    }
}
