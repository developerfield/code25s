package com.studytimer.app

import android.content.*
import android.net.Uri
import android.os.*
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.studytimer.app.service.FloatingWidgetService
import com.studytimer.app.service.TimerService
import com.studytimer.app.ui.StatsActivity

class MainActivity : AppCompatActivity() {

    // ── UI Elemanları ────────────────────────────────────────────
    private lateinit var tvTimer: TextView
    private lateinit var tvMode: TextView
    private lateinit var tvSession: TextView
    private lateinit var btnStudy: Button
    private lateinit var btnBreak: Button
    private lateinit var btnStart: Button
    private lateinit var btnStop: Button
    private lateinit var btnStats: ImageButton
    private lateinit var btnTheme: ImageButton
    private lateinit var btnFloat: ImageButton
    private lateinit var btnPomodoro: ToggleButton
    private lateinit var progressBar: ProgressBar

    // ── Durum ────────────────────────────────────────────────────
    private var isDarkTheme = false
    private var isRunning = false
    private var isStudyMode = true
    private var elapsedSeconds = 0L
    private var pomodoroEnabled = false

    // ── BroadcastReceiver (Timer servisinden güncellemeleri alır) ─
    private val timerReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                TimerService.ACTION_TICK -> {
                    elapsedSeconds = intent.getLongExtra(TimerService.EXTRA_ELAPSED, 0)
                    isRunning = intent.getBooleanExtra(TimerService.EXTRA_RUNNING, false)
                    isStudyMode = intent.getBooleanExtra(TimerService.EXTRA_STUDY_MODE, true)
                    pomodoroEnabled = intent.getBooleanExtra(TimerService.EXTRA_POMODORO, false)
                    updateUI()
                }
                TimerService.ACTION_POMODORO_SWITCH -> {
                    val toStudy = intent.getBooleanExtra(TimerService.EXTRA_STUDY_MODE, true)
                    showPomodoroAlert(toStudy)
                }
            }
        }
    }

    // ────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        setupListeners()
        registerReceiver()
        // Servisi başlat (arka planda zaten çalışıyorsa devam eder)
        startTimerService()
    }

    override fun onResume() {
        super.onResume()
        // Servisten güncel durumu iste
        sendBroadcast(Intent(TimerService.ACTION_REQUEST_STATE))
    }

    override fun onDestroy() {
        super.onDestroy()
        LocalBroadcastManager.getInstance(this).unregisterReceiver(timerReceiver)
    }

    // ── View Bağlama ─────────────────────────────────────────────
    private fun bindViews() {
        tvTimer    = findViewById(R.id.tvTimer)
        tvMode     = findViewById(R.id.tvMode)
        tvSession  = findViewById(R.id.tvSession)
        btnStudy   = findViewById(R.id.btnStudy)
        btnBreak   = findViewById(R.id.btnBreak)
        btnStart   = findViewById(R.id.btnStart)
        btnStop    = findViewById(R.id.btnStop)
        btnStats   = findViewById(R.id.btnStats)
        btnTheme   = findViewById(R.id.btnTheme)
        btnFloat   = findViewById(R.id.btnFloat)
        btnPomodoro= findViewById(R.id.btnPomodoro)
        progressBar= findViewById(R.id.progressBar)
    }

    // ── Listener Kurulumu ────────────────────────────────────────
    private fun setupListeners() {

        // ▶ DERS modu butonu
        btnStudy.setOnClickListener {
            sendServiceCommand(TimerService.CMD_SET_STUDY)
            isStudyMode = true
            updateModeButtons()
        }

        // ▶ MOLA modu butonu
        btnBreak.setOnClickListener {
            sendServiceCommand(TimerService.CMD_SET_BREAK)
            isStudyMode = false
            updateModeButtons()
        }

        // ▶ BAŞLA butonu
        btnStart.setOnClickListener {
            sendServiceCommand(TimerService.CMD_START)
            isRunning = true
            updateButtonStates()
        }

        // ▶ BİTİR butonu
        btnStop.setOnClickListener {
            sendServiceCommand(TimerService.CMD_STOP)
            isRunning = false
            updateButtonStates()
        }

        // ▶ İstatistikler
        btnStats.setOnClickListener {
            startActivity(Intent(this, StatsActivity::class.java))
        }

        // ▶ Tema geçişi
        btnTheme.setOnClickListener {
            isDarkTheme = !isDarkTheme
            AppCompatDelegate.setDefaultNightMode(
                if (isDarkTheme) AppCompatDelegate.MODE_NIGHT_YES
                else AppCompatDelegate.MODE_NIGHT_NO
            )
        }

        // ▶ Yüzen widget
        btnFloat.setOnClickListener {
            if (checkOverlayPermission()) {
                toggleFloatingWidget()
            }
        }

        // ▶ Pomodoro modu
        btnPomodoro.setOnCheckedChangeListener { _, checked ->
            pomodoroEnabled = checked
            sendServiceCommand(
                if (checked) TimerService.CMD_POMODORO_ON
                else TimerService.CMD_POMODORO_OFF
            )
        }
    }

    // ── Receiver Kayıt ──────────────────────────────────────────
    private fun registerReceiver() {
        val filter = IntentFilter().apply {
            addAction(TimerService.ACTION_TICK)
            addAction(TimerService.ACTION_POMODORO_SWITCH)
        }
        LocalBroadcastManager.getInstance(this)
            .registerReceiver(timerReceiver, filter)
    }

    // ── Servis İletişimi ─────────────────────────────────────────
    private fun startTimerService() {
        val intent = Intent(this, TimerService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    private fun sendServiceCommand(command: String) {
        val intent = Intent(this, TimerService::class.java)
            .setAction(command)
        startService(intent)
    }

    // ── UI Güncelleme ────────────────────────────────────────────
    private fun updateUI() {
        // Sayaç formatı: 00:00:00
        val h = elapsedSeconds / 3600
        val m = (elapsedSeconds % 3600) / 60
        val s = elapsedSeconds % 60
        tvTimer.text = String.format("%02d:%02d:%02d", h, m, s)

        // Pomodoro progress bar
        if (pomodoroEnabled) {
            val limit = if (isStudyMode) TimerService.POMODORO_STUDY_SEC
                        else TimerService.POMODORO_BREAK_SEC
            progressBar.max = limit.toInt()
            progressBar.progress = (elapsedSeconds % limit).toInt()
            progressBar.visibility = View.VISIBLE
        } else {
            progressBar.visibility = View.GONE
        }

        updateModeButtons()
        updateButtonStates()
    }

    private fun updateModeButtons() {
        val studyColor   = ContextCompat.getColor(this, R.color.study_color)
        val breakColor   = ContextCompat.getColor(this, R.color.break_color)
        val inactiveColor= ContextCompat.getColor(this, R.color.button_inactive)

        if (isStudyMode) {
            btnStudy.setBackgroundColor(studyColor)
            btnBreak.setBackgroundColor(inactiveColor)
            tvMode.text = "📚 Ders Modu"
            tvMode.setTextColor(studyColor)
        } else {
            btnStudy.setBackgroundColor(inactiveColor)
            btnBreak.setBackgroundColor(breakColor)
            tvMode.text = "☕ Mola Modu"
            tvMode.setTextColor(breakColor)
        }
    }

    private fun updateButtonStates() {
        btnStart.isEnabled = !isRunning
        btnStop.isEnabled  = isRunning
        btnStart.alpha = if (isRunning) 0.5f else 1.0f
        btnStop.alpha  = if (isRunning) 1.0f else 0.5f
    }

    // ── Overlay İzni ─────────────────────────────────────────────
    private fun checkOverlayPermission(): Boolean {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQ_OVERLAY)
            Toast.makeText(this, "Lütfen 'Diğer uygulamaların üzerinde göster' iznini verin", Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }

    // ── Yüzen Widget ─────────────────────────────────────────────
    private var isFloating = false
    private fun toggleFloatingWidget() {
        val svc = Intent(this, FloatingWidgetService::class.java)
        if (isFloating) {
            stopService(svc)
            btnFloat.setImageResource(R.drawable.ic_bubble_off)
        } else {
            ContextCompat.startForegroundService(this, svc)
            btnFloat.setImageResource(R.drawable.ic_bubble_on)
        }
        isFloating = !isFloating
    }

    // ── Pomodoro Geçiş Uyarısı ───────────────────────────────────
    private fun showPomodoroAlert(toStudy: Boolean) {
        val msg = if (toStudy) "🎉 Mola bitti! Ders zamanı." else "☕ Süper! Molaya geç."
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val REQ_OVERLAY = 1001
    }
}
