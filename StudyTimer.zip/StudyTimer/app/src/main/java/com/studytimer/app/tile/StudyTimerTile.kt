package com.studytimer.app.tile

import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import com.studytimer.app.service.TimerService

/**
 * Ekranı yukarıdan aşağıya kaydırınca görünen Quick Settings tile.
 * "Ders Sayacı" tile'ına dokunmak → Başlat/Durdur geçişi yapar.
 * Uzun basış → Ana uygulamayı açar.
 */
@RequiresApi(Build.VERSION_CODES.N)
class StudyTimerTile : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile(active = false, label = "Ders Sayacı")
    }

    override fun onClick() {
        super.onClick()
        // Tile durumuna göre Başlat veya Durdur
        val tile = qsTile ?: return
        if (tile.state == Tile.STATE_ACTIVE) {
            sendCmd(TimerService.CMD_STOP)
            updateTile(active = false, label = "Ders Sayacı")
        } else {
            sendCmd(TimerService.CMD_START)
            updateTile(active = true, label = "Sayaç ▶")
        }
    }

    override fun onLongClick() {
        // Ana uygulamayı aç
        startActivityAndCollapse(
            Intent(applicationContext, com.studytimer.app.MainActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
        )
    }

    // ── Yardımcılar ──────────────────────────────────────────────
    private fun updateTile(active: Boolean, label: String) {
        qsTile?.apply {
            state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            this.label = label
            updateTile()
        }
    }

    private fun sendCmd(action: String) {
        startService(Intent(this, TimerService::class.java).setAction(action))
    }
}
