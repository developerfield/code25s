package com.studytimer.app.service

import android.app.*
import android.content.*
import android.media.RingtoneManager
import android.os.*
import androidx.core.app.NotificationCompat
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.studytimer.app.MainActivity
import com.studytimer.app.R
import com.studytimer.app.data.SessionRepository
import com.studytimer.app.model.StudySession
import com.studytimer.app.receiver.NotificationReceiver
import kotlinx.coroutines.*

class TimerService : Service() {

    // ── Durum Değişkenleri ───────────────────────────────────────
    private var isRunning   = false
    private var isStudyMode = true
    private var pomodoroOn  = false
    private var elapsedSec  = 0L
    private var sessionStart= 0L

    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    private var timerJob: Job? = null

    private lateinit var repo: SessionRepository
    private lateinit var vibrator: Vibrator

    // ────────────────────────────────────────────────────────────
    override fun onCreate() {
        super.onCreate()
        repo     = SessionRepository(this)
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        }
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            CMD_START        -> startTimer()
            CMD_STOP         -> stopTimer()
            CMD_SET_STUDY    -> setMode(study = true)
            CMD_SET_BREAK    -> setMode(study = false)
            CMD_POMODORO_ON  -> { pomodoroOn = true;  broadcastState() }
            CMD_POMODORO_OFF -> { pomodoroOn = false; broadcastState() }
            ACTION_REQUEST_STATE -> broadcastState()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        timerJob?.cancel()
        serviceScope.cancel()
        super.onDestroy()
    }

    // ── Timer Kontrolü ───────────────────────────────────────────
    private fun startTimer() {
        if (isRunning) return
        isRunning   = true
        sessionStart= System.currentTimeMillis()
        timerJob = serviceScope.launch {
            while (isActive && isRunning) {
                delay(1000)
                elapsedSec++
                broadcastTick()
                updateNotification()
                checkPomodoro()
            }
        }
        broadcastState()
    }

    private fun stopTimer() {
        if (!isRunning) return
        isRunning = false
        timerJob?.cancel()
        // Oturumu kaydet
        if (elapsedSec > 0) {
            serviceScope.launch {
                repo.insertSession(
                    StudySession(
                        startTime  = sessionStart,
                        endTime    = System.currentTimeMillis(),
                        durationSec= elapsedSec,
                        isStudy    = isStudyMode
                    )
                )
            }
        }
        elapsedSec = 0
        broadcastState()
        updateNotification()
    }

    private fun setMode(study: Boolean) {
        if (isStudyMode == study) return
        // Mevcut oturumu kaydet
        if (isRunning && elapsedSec > 0) {
            val now = System.currentTimeMillis()
            serviceScope.launch {
                repo.insertSession(
                    StudySession(
                        startTime  = sessionStart,
                        endTime    = now,
                        durationSec= elapsedSec,
                        isStudy    = isStudyMode
                    )
                )
            }
            sessionStart = System.currentTimeMillis()
            elapsedSec   = 0
        }
        isStudyMode = study
        broadcastState()
        updateNotification()
    }

    // ── Pomodoro Kontrolü ────────────────────────────────────────
    private fun checkPomodoro() {
        if (!pomodoroOn) return
        val limit = if (isStudyMode) POMODORO_STUDY_SEC else POMODORO_BREAK_SEC
        if (elapsedSec > 0 && elapsedSec % limit == 0L) {
            // Mod geçişi
            val switchToStudy = !isStudyMode
            setMode(switchToStudy)
            alertPomodoroSwitch(switchToStudy)
        }
    }

    private fun alertPomodoroSwitch(toStudy: Boolean) {
        // Titreşim
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 200, 300), -1))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(longArrayOf(0, 300, 200, 300), -1)
        }
        // Ses
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            RingtoneManager.getRingtone(this, uri)?.play()
        } catch (_: Exception) {}

        // UI'ya bildir
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(ACTION_POMODORO_SWITCH).putExtra(EXTRA_STUDY_MODE, toStudy)
        )
    }

    // ── Broadcast ────────────────────────────────────────────────
    private fun broadcastTick() {
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(ACTION_TICK).apply {
                putExtra(EXTRA_ELAPSED,    elapsedSec)
                putExtra(EXTRA_RUNNING,    isRunning)
                putExtra(EXTRA_STUDY_MODE, isStudyMode)
                putExtra(EXTRA_POMODORO,   pomodoroOn)
            }
        )
    }

    private fun broadcastState() {
        LocalBroadcastManager.getInstance(this).sendBroadcast(
            Intent(ACTION_TICK).apply {
                putExtra(EXTRA_ELAPSED,    elapsedSec)
                putExtra(EXTRA_RUNNING,    isRunning)
                putExtra(EXTRA_STUDY_MODE, isStudyMode)
                putExtra(EXTRA_POMODORO,   pomodoroOn)
            }
        )
    }

    // ── Bildirim ─────────────────────────────────────────────────
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(
                CHANNEL_ID, "Study Timer", NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Ders sayacı bildirimi" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(): Notification {
        val h = elapsedSec / 3600
        val m = (elapsedSec % 3600) / 60
        val s = elapsedSec % 60
        val timeStr = String.format("%02d:%02d:%02d", h, m, s)
        val modeStr = if (isStudyMode) "📚 Ders" else "☕ Mola"

        // Açma intent'i
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // Başla/Durdur action
        val toggleAction = if (isRunning) {
            makeAction("⏸ Duraklat", NotificationReceiver.ACTION_PAUSE)
        } else {
            makeAction("▶ Başla",    NotificationReceiver.ACTION_START)
        }

        // Ders/Mola action
        val modeAction = if (isStudyMode) {
            makeAction("☕ Mola",   NotificationReceiver.ACTION_BREAK)
        } else {
            makeAction("📚 Ders",   NotificationReceiver.ACTION_STUDY)
        }

        // Bitir action
        val stopAction = makeAction("⏹ Bitir", NotificationReceiver.ACTION_STOP)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_study)
            .setContentTitle("$modeStr — $timeStr")
            .setContentText(if (isRunning) "Sayaç çalışıyor" else "Duraklatıldı")
            .setContentIntent(openIntent)
            .addAction(toggleAction)
            .addAction(modeAction)
            .addAction(stopAction)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun makeAction(label: String, action: String): NotificationCompat.Action {
        val pi = PendingIntent.getBroadcast(
            this, action.hashCode(),
            Intent(this, NotificationReceiver::class.java).setAction(action),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Action(0, label, pi)
    }

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification())
    }

    // ── Sabitler ─────────────────────────────────────────────────
    companion object {
        const val CHANNEL_ID = "study_timer_channel"
        const val NOTIF_ID   = 101

        // Komutlar (onStartCommand action'ları)
        const val CMD_START        = "com.studytimer.CMD_START"
        const val CMD_STOP         = "com.studytimer.CMD_STOP"
        const val CMD_SET_STUDY    = "com.studytimer.CMD_STUDY"
        const val CMD_SET_BREAK    = "com.studytimer.CMD_BREAK"
        const val CMD_POMODORO_ON  = "com.studytimer.CMD_POMODORO_ON"
        const val CMD_POMODORO_OFF = "com.studytimer.CMD_POMODORO_OFF"

        // Broadcast action'ları
        const val ACTION_TICK          = "com.studytimer.TICK"
        const val ACTION_POMODORO_SWITCH= "com.studytimer.POMODORO_SWITCH"
        const val ACTION_REQUEST_STATE  = "com.studytimer.REQUEST_STATE"

        // Extras
        const val EXTRA_ELAPSED    = "elapsed"
        const val EXTRA_RUNNING    = "running"
        const val EXTRA_STUDY_MODE = "study_mode"
        const val EXTRA_POMODORO   = "pomodoro"

        // Pomodoro süreleri (saniye)
        const val POMODORO_STUDY_SEC = 25 * 60L  // 25 dakika
        const val POMODORO_BREAK_SEC =  5 * 60L  //  5 dakika
    }
}
