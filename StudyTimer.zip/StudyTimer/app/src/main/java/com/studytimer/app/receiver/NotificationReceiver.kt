package com.studytimer.app.receiver

import android.content.*
import com.studytimer.app.service.TimerService

/**
 * Bildirim çubuğundaki butonlardan gelen broadcast'leri alır
 * ve TimerService'e iletir.
 */
class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val cmd = when (intent.action) {
            ACTION_START -> TimerService.CMD_START
            ACTION_PAUSE -> TimerService.CMD_STOP   // Duraklat = geçici durdur
            ACTION_STUDY -> TimerService.CMD_SET_STUDY
            ACTION_BREAK -> TimerService.CMD_SET_BREAK
            ACTION_STOP  -> TimerService.CMD_STOP
            else         -> return
        }
        context.startService(
            Intent(context, TimerService::class.java).setAction(cmd)
        )
    }

    companion object {
        const val ACTION_START = "com.studytimer.ACTION_START"
        const val ACTION_PAUSE = "com.studytimer.ACTION_PAUSE"
        const val ACTION_STUDY = "com.studytimer.ACTION_STUDY"
        const val ACTION_BREAK = "com.studytimer.ACTION_BREAK"
        const val ACTION_STOP  = "com.studytimer.ACTION_STOP"
    }
}
