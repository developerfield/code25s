package com.studytimer.app.ui

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.studytimer.app.R
import com.studytimer.app.data.SessionRepository
import kotlinx.coroutines.launch

class StatsActivity : AppCompatActivity() {

    private lateinit var tvTotalStudy: TextView
    private lateinit var tvTotalBreak: TextView
    private lateinit var tvTotalSession: TextView
    private lateinit var llWeekly: LinearLayout

    private lateinit var repo: SessionRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_stats)

        tvTotalStudy  = findViewById(R.id.tvTotalStudy)
        tvTotalBreak  = findViewById(R.id.tvTotalBreak)
        tvTotalSession= findViewById(R.id.tvTotalSession)
        llWeekly      = findViewById(R.id.llWeekly)

        repo = SessionRepository(this)
        loadStats()
    }

    private fun loadStats() {
        lifecycleScope.launch {
            val studySec   = repo.totalStudySec()
            val breakSec   = repo.totalBreakSec()
            val allSessions= repo.getAllSessions()
            val weekly     = repo.weeklyStudySec()

            // Toplam süreler
            tvTotalStudy.text  = "📚 Toplam Ders: ${formatTime(studySec)}"
            tvTotalBreak.text  = "☕ Toplam Mola: ${formatTime(breakSec)}"
            tvTotalSession.text= "🗂 Oturum Sayısı: ${allSessions.size}"

            // Haftalık bar grafik (basit TextView tabanlı)
            llWeekly.removeAllViews()
            if (weekly.isEmpty()) {
                val noData = TextView(this@StatsActivity).apply {
                    text = "Henüz veri yok"
                    textSize = 14f
                }
                llWeekly.addView(noData)
            } else {
                val maxVal = weekly.maxOf { it.total }.coerceAtLeast(1L)
                weekly.forEach { dayTotal ->
                    val row = LinearLayout(this@StatsActivity).apply {
                        orientation = LinearLayout.HORIZONTAL
                        setPadding(0, 8, 0, 8)
                    }
                    val dayLabel = TextView(this@StatsActivity).apply {
                        text = dayTotal.day.takeLast(5) // MM-DD
                        textSize = 12f
                        width = 120
                    }
                    val barWidth = ((dayTotal.total.toFloat() / maxVal) * 600).toInt().coerceAtLeast(8)
                    val bar = TextView(this@StatsActivity).apply {
                        width = barWidth
                        height = 48
                        setBackgroundColor(resources.getColor(R.color.study_color, theme))
                    }
                    val timeLabel = TextView(this@StatsActivity).apply {
                        text = " ${formatTime(dayTotal.total)}"
                        textSize = 12f
                    }
                    row.addView(dayLabel)
                    row.addView(bar)
                    row.addView(timeLabel)
                    llWeekly.addView(row)
                }
            }
        }
    }

    private fun formatTime(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        return if (h > 0) "${h}s ${m}d" else "${m}d"
    }
}
